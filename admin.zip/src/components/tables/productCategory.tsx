const productCategory = ()=>{
    return(
        <div>
            a
        </div>
    )
}
export default productCategory;