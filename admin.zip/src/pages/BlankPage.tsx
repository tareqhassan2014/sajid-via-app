const BlankPage = () => {
    return (
        <div></div>
    )
}
export default BlankPage